


int main(void)
{
        char c;
        char *p ;
        char **p2;

        p2 = &p;

        
        
        int a;                  /* a 的值，  0，  */
}

