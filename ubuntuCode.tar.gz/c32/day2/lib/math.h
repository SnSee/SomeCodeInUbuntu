
#ifndef __MATH_H__
#define __MATH_H__


extern int add(int a, int b );
extern int sub(int , int);



#endif  /* __MATH_H__ */
