

#include <stdio.h>

#define N 1024


int main(int argc, char *argv[])
{
        int a = N;

        printf("Hello World!\n");
        return 0;
}
