#ifndef _SORT_H_
#define _SORT_H_

void insertionSort(int *array, int len);
void selectionSort(int *array, int len);

#endif // _SORT_H_
