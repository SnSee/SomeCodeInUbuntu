#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/*
 * function: create a server with bufferevent in libevent 
 */
void func1(){
	
}

int main(int argc, char *argv[])
{
	func1();

	return 0;
}
