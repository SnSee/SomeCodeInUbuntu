#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "openssl/hmac.h"
#include "openssl/sha.h"

/*
 * function: 使用HMAC相关函数计算哈希值 
 */
void func1(){
	printf("func1:\n");
	HMAC_CTX *ctx = HMAC_CTX_new();

	HMAC_Init_ex(ctx, "12345", 6, EVP_sha1(), NULL);
	HMAC_Update(ctx, "this is data", strlen("this is data"));
	unsigned char *result = malloc(20);
	unsigned int len;
	HMAC_Final(ctx, result, &len);
	
	int i = 0;
	for(i = 0; i < len; i++){
		printf("%02x", result[i]);
	}
	printf("\n");
	free(result);
}
void func2(){
	printf("func2:\n");
	unsigned char *result = malloc(20);
	unsigned int len;
	HMAC(EVP_sha1(), "12345", 6, "this is data", strlen("this is data"),
			result, &len);
	int i = 0;
	for(i = 0; i < len; i++){
		printf("%02x", result[i]);
	}
	printf("\n");
	free(result);
}
int main(int argc, char *argv[])
{
	func1();
	func2();

	return 0;
}
