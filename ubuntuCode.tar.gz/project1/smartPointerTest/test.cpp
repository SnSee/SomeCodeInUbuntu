//智能指针的用法
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory>
#include <iostream>
using namespace std;

int main()
{
	//1-第一种方法
	shared_ptr<int> ptr(new int(99));
	cout << *ptr << endl;
	cout << "ptr:引用计数:" << ptr.use_count() << endl;


	//2-第二种方法
	shared_ptr<int> ptr1 = make_shared<int>(88);
	cout << *ptr1 << endl;
	cout << "引用计数:" << ptr1.use_count() << endl;

	{
		shared_ptr<int> ptr3 = ptr1;
		cout << "引用计数:" << ptr3.use_count() << endl;
	}

	//3-第三种方法
	shared_ptr<int> ptr2 = ptr1;
	cout << *ptr2 << endl;
	cout << "ptr2:引用计数:" << ptr1.use_count() << endl;

	int *p = new int(10);
	ptr2.reset(p);
	cout << "ptr1:引用计数:" << ptr1.use_count() << endl;
	cout << "ptr:引用计数:" << ptr.use_count() << endl;

	//获取内存地址
	cout << ptr1.get() << endl;
	cout << ptr2.get() << endl;
	cout << ptr1 << endl;
	cout << ptr2 << endl;

	return 0;

}
