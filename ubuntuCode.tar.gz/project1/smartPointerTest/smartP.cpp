#include <iostream>
#include <string>
#include <memory>
using namespace std;
class A{
public:
	A(){
		cout << "construct A()" << endl;
	}
	A(int a){
		cout << "construct A(int)" << endl;
	}
	A(string s){
		cout << "construct A(string)" << endl;
	}
	~A(){
		cout << "destruct A()" << endl;
	}
};
void func1(){
	{
		shared_ptr<A> sp1(new A());
		shared_ptr<A> sp2 = make_shared<A>(10);
		A *a = new A("string");
		shared_ptr<A> sp3;
		sp3.reset(a);
	}
}
void func2(){

}
int main(int argc, char *argv[]){
	
#if 0
	//method 1:
	shared_ptr<int> sptr(new int(1));
	cout << "*sptr = " << *sptr << endl;

	//method 2:
	shared_ptr<int> sptr1 = make_shared<int>(10); 
	cout << "*sptr1 = " << *sptr1 << endl;

	//method 3:
	shared_ptr<int> sptr2 = sptr1;
	cout << "*sptr2 = " << *sptr2 << endl;
	cout << "sptr1引用计数:" << sptr1.use_count() << endl;
	cout << "sptr2引用计数:" << sptr2.use_count() << endl;
	
	cout << "sptr1:" << sptr1.get() << endl;
	cout << "sptr2:" << sptr2.get() << endl;

	//method 4:
	int *pint = new int(40);
	shared_ptr<int> sptr3;
	sptr3.reset(pint);
	cout << "*sptr3 = " << *sptr3 << endl;
#endif

	func1();

	return 0;
}
