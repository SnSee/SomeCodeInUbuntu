#ifndef __SHARE_MEM__
#define __SHARE_MEM__
#include <iostream>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/shm.h>
using namespace std;

class ShareMem{
public:
	//创建共享内存
	ShareMem(const char *path, unsigned int size);
	//获取共享内存对应到本进程虚拟内存地址
	char *getShareMem();
	//释放共享内存
	int freeShareMem();

private:
	key_t key;
	int shmid;
	unsigned int m_size;
	char *m_path;
	char *shmaddr;
};

#endif
