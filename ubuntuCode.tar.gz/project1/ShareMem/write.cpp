#include <string.h>
#include "shareMem.h"

int main(int argc, char *argv[]){

	unsigned int size = 1024;
	ShareMem *shm = new ShareMem("/home/snsee/project1/ShareMem/shareMem.h", size);
	char *shmaddr = shm->getShareMem();
	memset(shmaddr, 0, 1024);
	strcpy(shmaddr, "Fine");
	getchar();	
	shm->freeShareMem();

	delete shm;
	return 0;
}
