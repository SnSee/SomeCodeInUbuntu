#include "shareMem.h"

ShareMem::ShareMem(const char *path, unsigned int size){
	//初始化
	m_path = (char *)path;
	m_size = size;
	//创建共享内存键值
	key = ftok(m_path, 10);
	//创建共享内存
	shmid = shmget(key, m_size, IPC_CREAT|IPC_EXCL|0755);
	if(shmid < 0){
		if(errno == EEXIST){
			shmid = shmget(key, 0, 0);
			if(shmid < 0){
				perror("shmget");
				exit(-1);
			}
		}
		else{
			perror("shmget");
			exit(-1);
		}
	}
	printf("shmid = [%d]\n", shmid);
}
//获取共享内存
char *ShareMem::getShareMem(){
	shmaddr = (char *)shmat(shmid, NULL, 0);
	printf("shmaddr = [%p]\n", shmaddr);
	return shmaddr;
}
//释放共享内存
int ShareMem::freeShareMem(){
	shmdt(shmaddr);
	shmctl(shmid, IPC_RMID, NULL);
	return 0;
}
