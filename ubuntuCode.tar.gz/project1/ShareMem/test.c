#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

/*
 * function: 
 */
void func1(){
	printf("PAGE_SIZE = [%d]\n", PAGE_SIZE);	
}

int main(int argc, char *argv[])
{
	func1();

	return 0;
}
