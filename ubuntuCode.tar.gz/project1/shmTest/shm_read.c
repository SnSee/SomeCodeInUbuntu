#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>

/*
 * function: write into the shared memory 
 */
void func1(){
	int ret = 0;
	int shmid = 0;
	//shmid = shmget(0x12345678, 1024, IPC_CREAT|IPC_EXCL|0755);	
	key_t key = ftok("/home/snsee/project1/shmTest/a.txt", 10);
	shmid = shmget(key, 1024, IPC_CREAT|IPC_EXCL|0755);
	if(shmid < 0){
		if(errno == EEXIST){
			printf("the memory has already exists\n");
			shmid = shmget(key, 0, 0);
			if(shmid < 0){
				return;
			}
		}
		else{
			return;
		}
	}

	char *addr = shmat(shmid, NULL, 0);
	char buf[64] = "";

	memcpy(buf, addr, sizeof(buf));
	printf("[%s]\n", buf);

	getchar();
	shmdt(addr);
	shmctl(shmid, IPC_RMID, NULL);

}

int main(int argc, char *argv[])
{
	func1();

	return 0;
}
