#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>

/*
 * function: write into the shared memory 
 */
void func1(){
	int ret = 0;
	int shmid = 0;
	key_t key = ftok("/home/snsee/project1/shmTest/a.txt", 10);
	printf("key = [%d]\n", key);
	//shmid = shmget(0x12345678, 1024, IPC_CREAT|IPC_EXCL|0755);	
	shmid = shmget(key, 1024, IPC_CREAT|IPC_EXCL|0755);
	if(shmid < 0){
	if(errno == EEXIST){
		printf("the memory has already exists\n");
		shmid = shmget(key, 0, 0);
		if(shmid < 0){
			perror("create shared memory\n");
			return;
		}
	}
	else{
		return;
	}
	}

	char *addr = shmat(shmid, NULL, 0);
	memset(addr, 0, 1024);

	memcpy(addr, "Hello", 1024);
	printf("addr = [%s]\n", addr);

	getchar();
	shmdt(addr);
	shmctl(shmid, IPC_RMID, NULL);	
}

int main(int argc, char *argv[])
{
	func1();

	return 0;
}
