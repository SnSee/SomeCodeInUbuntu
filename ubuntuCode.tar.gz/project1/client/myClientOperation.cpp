#include "myClientOperation.h"
#include "RequestCodec.h"
#include <string.h>
#include <time.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include "CodecFactory.h"
#include "RequestFactory.h"
#include "RespondFactory.h"

using namespace std;
MyClientOperation::MyClientOperation(ClientInfo *info){
	memcpy(&m_info, info, sizeof(ClientInfo));
	m_shm = new SecKeyShm(info->shmKey, info->maxNode);
}
MyClientOperation::~MyClientOperation(){
	m_shm->delShm();
	delete m_shm;
}
int MyClientOperation::consultKey(){
	RequestMsg reqMsg;
	reqMsg.cmdType = RequestCodec::NewOrUpdate;
	getRandString(sizeof(reqMsg.r1), reqMsg.r1);
	strcpy(reqMsg.clientId, m_info.clinetID);
	strcpy(reqMsg.serverId, m_info.serverID);

	unsigned int outLen = 0;
	HMAC_CTX *ctx = HMAC_CTX_new();
	char key[1024] = "";
	unsigned char md[SHA256_DIGEST_LENGTH];
	sprintf(key, "%s%s", m_info.serverID, m_info.clinetID);
	
	HMAC_Init(ctx, key, (int)strlen(key), EVP_sha256());
	HMAC_Update(ctx, (unsigned char *)reqMsg.r1, strlen(reqMsg.r1));
	HMAC_Final(ctx, md, &outLen);
	for(int i = 0; i < SHA256_DIGEST_LENGTH; i++){
		sprintf(&reqMsg.authCode[i*2], "%02x", md[i]);
	}

	int len = -1;
	char *outData = NULL;
	CodecFactory *factory = new RequestFactory(&reqMsg);
	Codec *codec = factory->createCodec();
	codec->msgEncode(&outData, len);

	int ret = m_socket.connectToHost(m_info.serverIP, m_info.serverPort);
	if(-1 == ret){
		cout << "connect to server failed" << endl;
		return -1;
	}
	m_socket.sendMsg(outData, len);
	free(outData);

	char *recvBuf = NULL;
	m_socket.recvMsg(&recvBuf, len);

	delete factory;

	factory = new RespondFactory();
	codec = factory->createCodec();
	RespondMsg *resMsg = (RespondMsg*)codec->msgDecode(recvBuf, len);

	if(-1 == resMsg->rv){
		cout << "request failed" << endl;
		return -1;
	}

	unsigned char mdSha[SHA_DIGEST_LENGTH] = "";
	char keySha1[SHA_DIGEST_LENGTH*2 + 1] = "";
	sprintf(key, "%s%s", reqMsg.r1, resMsg->r2);
	SHA1((unsigned char *)key, strlen(key), mdSha);
	for(int i = 0; i < SHA_DIGEST_LENGTH; i++){
		sprintf(&keySha1[i*2], "%02x", mdSha[i]);
	}

	NodeSHMInfo shmInfo;
	shmInfo.status = 1;
	shmInfo.seckeyID = resMsg->seckeyid;
	strcpy(shmInfo.clientID, m_info.clinetID);
	strcpy(shmInfo.seckey, keySha1);
	strcpy(shmInfo.serverID, m_info.serverID);
	m_shm->shmWrite(&shmInfo);

	m_socket.freeMemory(&recvBuf);
	m_socket.disConnect();

	return 0;
}
void MyClientOperation::getRandString(int len, char * randBuf)
{
    int flag = -1;
    // 设置随机种子
    srand(time(NULL));
    // 随机字符串: A-Z, a-z, 0-9, 特殊字符(!@#$%^&*()_+=)
    char chars[] = "!@#$%^&*()_+=";
    for (int i = 0; i < len-1; ++i)
    {
        flag = rand() % 4;
        switch (flag)
        {
        case 0:
            randBuf[i] = rand() % 26 + 'A';
            break;
        case 1:
            randBuf[i] = rand() % 26 + 'a';
            break;
        case 2:
            randBuf[i] = rand() % 10 + '0';
            break;
        case 3:
            randBuf[i] = chars[rand() % strlen(chars)];
            break;
        default:
            break;
        }
    }
    randBuf[len - 1] = '\0';
}

