#ifndef __MY_CLIENTOPERATION__
#define __MY_CLIENTOPERATION__
#include "TcpServer.h"
#include "SecKeyShm.h"
class ClientInfo
{
public:
    char clinetID[12];          // 客户端ID
    char serverID[12];          // 服务器ID
    //char authCode[65];            // 消息认证码
    char serverIP[32];          // 服务器IP
    unsigned short serverPort;  // 服务器端口
    int maxNode;                // 共享内存节点个数
    int shmKey;                 // 共享内存的Key
};
class MyClientOperation{
public:
	MyClientOperation(ClientInfo *info);
	~MyClientOperation();

	int consultKey();
	int checkKey();
	int revokeKey();
	int displayKey();

private:
	void getRandString(int len, char *randBuf);

	ClientInfo m_info;
	TcpSocket m_socket;
	SecKeyShm *m_shm;
};
#endif
