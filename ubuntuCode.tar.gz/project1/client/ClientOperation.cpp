﻿#include "ClientOperation.h"
#include "RequestCodec.h"
#include <string.h>
#include <time.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include "CodecFactory.h"
#include "RequestFactory.h"
#include "RespondFactory.h"

using namespace std;

ClientOperation::ClientOperation(ClientInfo * info)
{
	memcpy(&m_info, info, sizeof(ClientInfo));
	// 创建共享内存对象
	m_shm = new SecKeyShm(info->shmKey, info->maxNode);
}

ClientOperation::~ClientOperation()
{
	m_shm->delShm();
	delete m_shm;
}

/*int ClientOperation::secKeyAgree()
{
	// 1. 准备好要发送的数据 RequestMsg
	RequestMsg reqMsg;
	reqMsg.cmdType = RequestCodec::NewOrUpdate;
	getRandString(sizeof(reqMsg.r1), reqMsg.r1);
	strcpy(reqMsg.clientId, m_info.clinetID);
	strcpy(reqMsg.serverId, m_info.serverID);
	// 1.1 生成消息认证码
	unsigned int outLen = -1;
	HMAC_CTX* ctx = HMAC_CTX_new();
	char key[1024] = { 0 };
	unsigned char md[SHA256_DIGEST_LENGTH];
	sprintf(key, "@%s+%s@", m_info.serverID, m_info.clinetID);
	cout << "key: " << key << endl;
	HMAC_Init(ctx, key, (int)strlen(key), EVP_sha256());
	HMAC_Update(ctx, (unsigned char*)reqMsg.r1, strlen(reqMsg.r1));
	HMAC_Final(ctx, md, &outLen);
	// 散列值->16进制格式数字串
	for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i)
	{
		sprintf(&reqMsg.authCode[i * 2], "%02x", md[i]);
	}
	cout << "原始数据: " << reqMsg.r1 << endl;
	cout << "生成的消息认证码: " << reqMsg.authCode << endl;

	// 2. 将要发送的数据序列化
	// 2.1 创建工厂对象
	int len = -1;
	char* outData = NULL;
	CodecFactory *factory = new RequestFactory(&reqMsg);
	Codec* codec = factory->createCodec();
	codec->msgEncode(&outData, len);

	// 3. 套接字通信
	// 3.1 连接服务器
	int ret = m_socket.connectToHost(m_info.serverIP, m_info.serverPort);
	if (ret == -1)
	{
		cout << "连接服务器失败" << endl;
		perror("connect error");
		return -1;
	}
	cout << "连接服务器成功..." << endl;
	// 3.2 发送数据
	m_socket.sendMsg(outData, len);
	// 3.3 释放内存
	free(outData);

	// 4. 等待并接收数据
	char* recvBuf = NULL;
	m_socket.recvMsg(&recvBuf, len);

	// 5. 删除工厂对象
	delete factory;

	// 5. 将数据解码
	factory = new RespondFactory();
	codec = factory->createCodec();
	RespondMsg *resMsg = (RespondMsg *)codec->msgDecode(recvBuf, len);

	// 6. 数据判断
	if (resMsg->rv == -1)
	{
		cout << "服务器处理请求失败..." << endl;
		return -1;
	}
	// 7. 生成秘钥
	unsigned char mdSha[SHA_DIGEST_LENGTH];
	char keySha1[SHA_DIGEST_LENGTH * 2 + 1] = { 0 };
	sprintf(key, "%s%s", reqMsg.r1, resMsg->r2);
	SHA1((unsigned char*)key, strlen(key), mdSha);
	for (int i = 0; i < SHA_DIGEST_LENGTH; ++i)
	{
		sprintf(&keySha1[i * 2], "%02x", mdSha[i]);
	}
	cout << "客户端生成的秘钥: " << keySha1 << endl;

	// 8. 将秘钥写入共享内存
	NodeSHMInfo shmInfo;
	shmInfo.status = 1;
	shmInfo.seckeyID = resMsg->seckeyid;
	strcpy(shmInfo.clientID, m_info.clinetID);
	strcpy(shmInfo.seckey, keySha1);
	strcpy(shmInfo.serverID, m_info.serverID);
	m_shm->shmWrite(&shmInfo);

	// 9. 释放内存
	m_socket.freeMemory(&recvBuf);
	m_socket.disConnect();

	return 0;
}*/
int ClientOperation::secKeyAgree()
{
	RequestMsg reqMsg;
	memset(&reqMsg, 0x00, sizeof(RequestMsg));
	reqMsg.cmdType = RequestCodec::NewOrUpdate;
	strcpy(reqMsg.clientId, m_info.clinetID);
	strcpy(reqMsg.serverId, m_info.serverID);
	getRandString(sizeof(reqMsg.r1), reqMsg.r1);
	
	//生成消息认证码       
	unsigned int outLen = -1;
	char key[1024] = { 0 };
	unsigned char md[SHA256_DIGEST_LENGTH];
	sprintf(key, "@%s+%s@", m_info.serverID, m_info.clinetID); 
	              
	HMAC(EVP_sha256(), key, strlen(key), (unsigned char *)reqMsg.r1, strlen(reqMsg.r1), md, &outLen);
	// 散列值->16进制格式数字串
	for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i)
	{
		sprintf(&reqMsg.authCode[i * 2], "%02x", md[i]);
	}
	cout << "key:" << key << endl;
	cout << "原始数据: " << reqMsg.r1 << endl;
	cout << "生成的消息认证码: " << reqMsg.authCode << endl;
	
	//对请求数据进行编码
	char *outData;
	int len;
	CodecFactory *factory = new RequestFactory(&reqMsg);
	Codec *pCodec = factory->createCodec();
	pCodec->msgEncode(&outData, len);
	cout << "编码成功" << endl;
	
	delete factory;
	delete pCodec;
	
	//发送数据到服务端
	char *inData;
	m_socket.connectToHost(m_info.serverIP, m_info.serverPort);
	m_socket.sendMsg(outData, len);
	free(outData);
	m_socket.recvMsg(&inData, len);
	
	//解码
	factory = new RespondFactory();
	pCodec = factory->createCodec();
	RespondMsg *resMsg = (RespondMsg *)pCodec->msgDecode(inData, len);
//	cout << "rv:" << resMsg->rv << endl;
//	cout << "clientId:" << resMsg->clientId << endl;
//	cout << "serverId:" << resMsg->serverId << endl;
//	cout << "r2:" << resMsg->r2 << endl;
//	cout << "seckeyid:" << resMsg->seckeyid << endl;
	
	delete factory;
	delete pCodec;
	m_socket.freeMemory(&inData);
	m_socket.disConnect();
	
	//判断结果
	if(resMsg->rv==0)
	{
		cout << "秘钥协商成功" << endl;
	}
	else 
	{
		cout << "秘钥协商失败" << endl;
		return -1;
	}
	
	//生成秘钥
	//unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);
	unsigned char mdSha[SHA_DIGEST_LENGTH];
	char keySha1[SHA_DIGEST_LENGTH * 2 + 1] = { 0 };
	sprintf(key, "%s%s", reqMsg.r1, resMsg->r2);
	SHA1((unsigned char*)key, strlen(key), mdSha);
	for (int i = 0; i < SHA_DIGEST_LENGTH; ++i)
	{
		sprintf(&keySha1[i * 2], "%02x", mdSha[i]);
	}
	cout << "客户端生成的秘钥: " << keySha1 << endl;
	
	//新生成的秘钥写入共享内存
	//连接共享内存
	NodeSHMInfo node;
	memset(&node, 0x00, sizeof(node));
	node.status = 0;
	node.seckeyID = resMsg->seckeyid;
	strcpy(node.clientID, reqMsg.clientId);
	strcpy(node.serverID, reqMsg.serverId);
	strcpy(node.seckey, keySha1);
	m_shm->shmWrite(&node);
	
	return 0;
}

// char randBuf[64]; , 参数 64, randBuf
void ClientOperation::getRandString(int len, char * randBuf)
{
	int flag = -1;
	// 设置随机种子
	srand(time(NULL));
	// 随机字符串: A-Z, a-z, 0-9, 特殊字符(!@#$%^&*()_+=)
	char chars[] = "!@#$%^&*()_+=";
	for (int i = 0; i < len-1; ++i)
	{
		flag = rand() % 4;
		switch (flag)
		{
		case 0:
			randBuf[i] = rand() % 26 + 'A';
			break;
		case 1:
			randBuf[i] = rand() % 26 + 'a';
			break;
		case 2:
			randBuf[i] = rand() % 10 + '0';
			break;
		case 3:
			randBuf[i] = chars[rand() % strlen(chars)];
			break;
		default:
			break;
		}
	}
	randBuf[len - 1] = '\0';
}
