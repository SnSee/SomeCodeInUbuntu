#include "dataManager.h"
DataManager::DataManager(){
	buf = new char[BUFSIZ];	
	memset(buf, 0, BUFSIZ);
}
DataManager::DataManager(int cfd){
	m_cfd = cfd;
	buf = new char[BUFSIZ];
	memset(buf, 0, BUFSIZ);
}
void DataManager::setConnFd(const int cfd){
	this->m_cfd = cfd;
}
char *DataManager::recvData(int *respondLen){
	//注意：需要将前四个字节解析为长度
	memset(buf, 0, BUFSIZ);
	int len_r = read(m_cfd, buf, BUFSIZ);
	if(len_r < 0){
		perror("read error");
		return NULL;
	}
	else if(0 == len_r){
		printf("服务器故障\n");
		return NULL;
	}
	//ITCAST_UINT32 itLen;
	memcpy(respondLen, buf, 4);
	printf("respondLen = %d\n", *respondLen);
	//*respondLen = itLen;	
	return buf + 4;
}
int DataManager::sendData(const char *data, int dataLen){
	//需要将长度信息添加到要发送的字符串中
    //用前四个字节存储长度
    unsigned char *dataToSend = (unsigned char *)malloc(dataLen + 4);
    ITCAST_UINT32 netLen = (ITCAST_UINT32)dataLen;
    memcpy(dataToSend, &netLen, 4);
    memcpy(dataToSend + 4, data, dataLen);
	int len_w = write(m_cfd, data, dataLen + 4);
	if(len_w < 0){
		perror("write error");
		return -1;
	}
	else if(0 == len_w){
		printf("服务器故障");
		return -1;
	}
	return 0;
}
DataManager::~DataManager(){
	delete []buf;
}
