#ifndef __MY_TYPES__
#define __MY_TYPES__
//请求类型
enum REQTYPE{
	KEY_CONSULT = 1,
	KEY_CHECK = 2,
	KEY_REVOKE = 3,
	KEY_DISPLAY = 4,
	CLIENT_EXIT = 0
};
enum RESPONDTYPE{
	RECV_SUCCEED,
	MSG_CHANGED,
	RECV_ERROR
};
//请求消息结构体
struct RequestMsg{
    int reqType;        //请求类型
    char clientId[12];	//客户端编号
    char serverId[12];  //服务端编号 
    char rstr[64];      //随机字符串
    char authCode[65];  //认证码
};
//应答消息结构体
struct RespondMsg{
	int respondType;	//响应消息类型
	char clientId[12];
	char serverId[12];
	char rstr[64];
	char authCode[65];
	int secretKeyId;	//对称密钥编号
};
//TODO
#endif
