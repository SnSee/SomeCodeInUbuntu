#include "genRespondMsg.h"

GenRespondMsg::GenRespondMsg(){
	this->m_respondMsg = new RespondMsg;
}
char *GenRespondMsg::setRespondMes(RespondMsg &respondMsg){
	m_respondMsg->respondType = respondMsg.respondType;
	strcpy(m_respondMsg->clientId, respondMsg.clientId);
	strcpy(m_respondMsg->serverId, respondMsg.serverId);
	getRandStr(m_respondMsg->rstr, sizeof(m_respondMsg->rstr));
	//调用散列函数的类生成哈希值()
	HashStr hashStr;
	hashStr.hashlizeStr(m_respondMsg->authCode, m_respondMsg->rstr, sizeof(m_respondMsg->rstr));	
	//把随机字符串和验证码复制到参数的结构体内
	memcpy(respondMsg.rstr, m_respondMsg->rstr, sizeof(respondMsg.rstr));
	memcpy(respondMsg.authCode, m_respondMsg->authCode,
			sizeof(respondMsg.authCode));
	char *msg = genRespondStr();
	return msg;
}
void GenRespondMsg::getRespondMes(RespondMsg &respondMsg, char *inData, int inDataLen){

	printf("before ungen\n");

	ungenRespondStr(inData, inDataLen);

	printf("after ungen\n");

	respondMsg.respondType = m_respondMsg->respondType;
	strcpy(respondMsg.clientId, m_respondMsg->clientId);
	strcpy(respondMsg.serverId, m_respondMsg->serverId);
	strcpy(respondMsg.rstr, m_respondMsg->rstr);
	strcpy(respondMsg.authCode, m_respondMsg->authCode);
	respondMsg.secretKeyId = m_respondMsg->secretKeyId;
}
char *GenRespondMsg::genRespondStr(){
	char *buf = NULL;
	int msgLen = 0;
	TlvMes *tlvMes = new TlvMes;
	tlvMes->encodeHeadNode(m_respondMsg->respondType);
	tlvMes->encodeNextNode(m_respondMsg->clientId);
	tlvMes->encodeNextNode(m_respondMsg->serverId);
	tlvMes->encodeNextNode(m_respondMsg->rstr);
	tlvMes->encodeNextNode(m_respondMsg->authCode);
	tlvMes->encodeNextNode(m_respondMsg->secretKeyId);
	//TODO:使用完msg后用free释放空间
	tlvMes->serializeStruct(&buf, &msgLen);
	char *msg = new char[msgLen];
	strcpy(msg, buf);
	tlvMes->freeAllNodes();

	delete tlvMes;
	return msg;
}
void GenRespondMsg::ungenRespondStr(char *inData, int inDataLen){
	TlvMes *tlvMes = new TlvMes;

	printf("before unserialize\n");

	printf("todelete inDataLen = %d\n", inDataLen);
	tlvMes->unserializeStruct(inData, inDataLen);

	printf("after unserialize\n");

	tlvMes->decodeHeadNode(&m_respondMsg->respondType);

	printf("after decodeHead\n");

	tlvMes->decodeNextNode(m_respondMsg->clientId);
	tlvMes->decodeNextNode(m_respondMsg->serverId);
	tlvMes->decodeNextNode(m_respondMsg->rstr);
	tlvMes->decodeNextNode(m_respondMsg->authCode);
	tlvMes->decodeNextNode(&m_respondMsg->secretKeyId);

	printf("before freeAllNodes\n");

	tlvMes->freeAllNodes();

	printf("after freeAllNodes\n");

	delete tlvMes;
	tlvMes = NULL;
}

char *GenRespondMsg::getRandStr(char *str, int strLen){
	srand(time(NULL));	
	int index, i = 0;
	for(i = 0; i < strLen; i++){
		index = rand() % 3;
		switch(index){
			case 0:
				str[i] = rand() % 10 + '0';			
				break;
			case 1:
				str[i] = rand() % 26 + 'a';
				break;
			case 2:
				str[i] = rand() % 26 + 'A';
				break;
		}
	}
	return str;
}
GenRespondMsg::~GenRespondMsg(){
	if(NULL != m_respondMsg){
		delete m_respondMsg;
		m_respondMsg = NULL;
	}
}
