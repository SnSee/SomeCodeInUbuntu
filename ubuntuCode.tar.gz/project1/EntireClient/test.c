#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "ItcastLog.h"

/*
 * function: 
 */
void func1(){
	ItcastLog il;	
}

int main(int argc, char *argv[])
{
	func1();

	return 0;
}
