#ifndef __TCPCONNCLT__
#define __TCPCONNCLT__
#include <sys/socket.h>
#include <sys/types.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
class TcpConnClt{
public:
	TcpConnClt();
	//创建连接，返回通信文件描述符，出错返回-1
	int startConnect(const char *srvIp, const short srvPort);
	~TcpConnClt();
private:
	int cfd;
};
#endif
