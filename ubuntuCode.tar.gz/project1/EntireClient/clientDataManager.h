#ifndef __SERVER_DATAMANAGER__
#define __SERVER_DATAMANAGER__
#include "dataManager.h"
#include "genRequestMsg.h"
#include "mytypes.h"
#include "hashStr.h"
class ClientDataManager :public DataManager{
public:
	ClientDataManager();
	~ClientDataManager();
private:
};
#endif
