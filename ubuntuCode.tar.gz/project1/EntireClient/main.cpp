#include <iostream>
#include "clientManager.h"
#include <time.h>
#include <stdlib.h>
using namespace std;
void startUI(){
	printf("**********************\n");
	printf("Welcome\n");
	printf("------------\n");
	return;
}
int main(int argc, char *argv[]){

	srand(time(NULL));
	char srvIp[] = "127.0.0.1";
	const short port = 8000;
	startUI();
	ClientManager cltManager(srvIp, port);
	if(0 > cltManager.startClient()){
		printf("start client failed\n");
		return -1;
	}	
	char serverId[12] = "serverId";
	char clientId[12] = "clientId";
	cltManager.setSrvCltId(serverId, clientId);
	cltManager.startWorking();

	return 0;
}
