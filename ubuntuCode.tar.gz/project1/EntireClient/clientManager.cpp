#include "clientManager.h"
ClientManager::ClientManager(char *srvIp, short port){
	m_srvIp = srvIp;
	m_srvPort = port;	
	tcpConnClt = new TcpConnClt();
	cfd = -1;
	dataManager = new ClientDataManager;
	genRequestMsg = new GenRequestMsg();
	genRespondMsg = new GenRespondMsg();
}
int ClientManager::startClient(){
	cfd = tcpConnClt->startConnect(m_srvIp, m_srvPort);
    if(cfd < 0){
    	return -1;
    }
	return cfd;
}
void ClientManager::setSrvCltId(const char *serverId, const char *clientId){
	m_serverId = (char *)serverId;
	m_clientId = (char *)clientId;
}
void ClientManager::startWorking(){
	dataManager->setConnFd(cfd);
	//TODO
	printf("1:密钥协商\n");
	printf("2:密钥校验\n");
	printf("3:密钥注销\n");
	printf("4:查询\n");
	printf("0:退出\n");
	while(1){
		int choice;
		cin >> choice;
		while(getchar()!='\n');
		switch(choice){
			case CLIENT_EXIT:
				exit(0);
				break;
			case KEY_CONSULT:
				consultSecretKey();
				break;
			case KEY_CHECK:
				break;
			case KEY_REVOKE:
				break;
			case KEY_DISPLAY:
				break;
			default:
				printf("无效输入\n");
				break;
		}
	}
}
//密钥协商
int ClientManager::consultSecretKey(){
	RequestMsg reqMsg;
	memset(&reqMsg, 0, sizeof(reqMsg));
	reqMsg.reqType = REQTYPE::KEY_CONSULT;
	strcpy(reqMsg.clientId, m_clientId);
	strcpy(reqMsg.serverId, m_serverId);
	//获取要发送的字符串
	char *outData = genRequestMsg->setRequestMes(reqMsg, &requestLen);
	dataManager->setConnFd(cfd);
	dataManager->sendData(outData, requestLen);
	printf("请求已发送\n");
	free(outData);	
	outData = NULL;

	//用于获取响应消息结构体
	RespondMsg respondMsg;
	//TODO:可以使用select设置最大等待响应时长
	//等待响应数据
	printf("todelete before recvData\n");
	char *inData = dataManager->recvData(&respondLen);
	printf("todelete after recvData\n");
	
	//TODO:检测是否生成及发送了正确数据
	char tempinData[12] = "";
	for(int i = 0; i < 5; i++){
        sprintf(tempinData + i*2, "%02x", inData[i]);
    }
	//TODO:长度不正确
	genRespondMsg->getRespondMes(respondMsg, inData, respondLen);	
	//打印收到的响应结构体
	//displayRespondMsg(respondMsg);
	return 0;
}
void ClientManager::displayRespondMsg(RespondMsg &respondMsg){
	printf("----Respond Received----\n");
	printf("respondType:%d\n", respondMsg.respondType);
	printf("clientId:%s\n", respondMsg.clientId);
	printf("serverId:%s\n", respondMsg.serverId);
	printf("rstr:%s\n", respondMsg.rstr);
	printf("authcode:%s\n", respondMsg.authCode);
	printf("secKeyId:%d\n", respondMsg.secretKeyId);
}
//密钥校验
int ClientManager::checkSecretKey(){
	return 0;
}
//密钥注销
int ClientManager::revokeSecretKey(){
	return 0;
}
//密钥查询
int ClientManager::displaySecretKey(){
	return 0;
}
ClientManager::~ClientManager(){
	if(NULL != tcpConnClt){
		delete tcpConnClt;
		tcpConnClt = NULL;
	}
	if(NULL != dataManager){
		delete dataManager;
		dataManager = NULL;
	}
	if(NULL != genRequestMsg){
		delete genRequestMsg;
		genRequestMsg = NULL;
	}
	if(NULL != genRespondMsg){
		delete genRespondMsg;
		genRespondMsg = NULL;
	}
	//关闭通信文件描述符
	if(cfd > 0){
		close(cfd);
	}
}
