#ifndef __GEN_RESPONDMSG__
#define __GEN_RESPONDMSG__
#include <iostream>
#include <string.h>
#include <ctime>
#include "tlvMes.h"
#include "hashStr.h"
#include "mytypes.h"
using namespace std;
//生成最终要发送的响应（调用编码及序列化类的方法）
//响应类型
//enum RESPONDTYPE{
//    RECV_SUCCEED,
//    MSG_CHANGED,
//    RECV_ERROR
//};
//应答消息结构体
//struct RespondMsg{
//    int respondType;    //响应消息类型
//    char clientId[12];
//    char serverId[12];
//    char rstr[64];
//    int secretKeyId;    //对称密钥编号
//};
class GenRespondMsg{
public:
	GenRespondMsg();
	~GenRespondMsg();
	//初始化响应消息结构体，传入的结构体不必包含随机字符串和验证码
	//返回要发送的字符串，使用完要free这个指针
	char *setRespondMes(RespondMsg &respondMsg);
	//返回解析后的响应消息结构体
	void getRespondMes(RespondMsg &respondMsg, char *inData, int inDataLen);
private:
	//将响应消息结构体转化成可传输的字符串，使用完成后要free掉返回的指针对应空间
	char *genRespondStr();
	//将收到的字符串解析成结构体
	void ungenRespondStr(char *inData, int inDataLen);
	//生成随机字符串
	char *getRandStr(char *str, int strLen);
private:
	RespondMsg *m_respondMsg;
};
#endif
