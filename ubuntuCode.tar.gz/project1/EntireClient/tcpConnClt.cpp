#include "tcpConnClt.h"
TcpConnClt::TcpConnClt(){

}
int TcpConnClt::startConnect(const char *srvIp, const short srvPort){
	cfd = socket(AF_INET, SOCK_STREAM, 0);
	if(cfd < 0){
		printf("in file %s line:%d:", __FILE__, __LINE__);
		perror("socket error");
		return -1;
	}
	struct sockaddr_in srvaddr;
	srvaddr.sin_family = AF_INET;
	srvaddr.sin_port = htons(srvPort);
	inet_pton(AF_INET, srvIp, &srvaddr.sin_addr.s_addr);
	//创建连接
	int ret = connect(cfd, (struct sockaddr*)&srvaddr, sizeof(srvaddr));
	if(ret < 0){
		perror("connect");
		return -1;
	}
	printf("成功连接服务器\n");

	return cfd;
}
TcpConnClt::~TcpConnClt(){

}
