#ifndef __SERVERMANAGER__
#define __SERVERMANAGER__
#include <iostream>
#include <unistd.h>
#include "tcpConnClt.h"
#include "clientDataManager.h"
#include "genRequestMsg.h"
#include "genRespondMsg.h"
#include "mytypes.h"
using namespace std;
//服务器管理
class ClientManager{
public:
	//传入服务器的ip和端口号
	ClientManager(char *srvIp, const short port);
	//设置客户端和服务器id
	void setSrvCltId(const char *serverId, const char *clientId);
	//开启客户端，返回通信文件描述符
	int startClient();
	//开始工作
	void startWorking();
	~ClientManager();
private:
	//密钥协商
	int consultSecretKey();
	//密钥校验
	int checkSecretKey();
	//密钥注销
	int revokeSecretKey();
	//密钥查询
	int displaySecretKey();
private:
	void displayRespondMsg(RespondMsg &respondMsg);
private:
	int cfd;
	TcpConnClt *tcpConnClt;	
	DataManager *dataManager;
	GenRequestMsg *genRequestMsg;
	GenRespondMsg *genRespondMsg;
	char *m_serverId, *m_clientId;
	char *m_srvIp;
	short m_srvPort;
	int requestLen;
	int respondLen;
};

#endif
