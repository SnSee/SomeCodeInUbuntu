#! /bin/bash
for fruit in apple banana strawberry
do
	echo $fruit
done

sum=0
for i in {1..100}
do
	sum=$[$sum+$i]
done

echo "sum = [$sum]"
