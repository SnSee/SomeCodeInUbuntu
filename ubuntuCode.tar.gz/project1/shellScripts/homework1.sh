# package files in a path and move it to another path
tar czvf $1 $2 
if [ $? -eq 0 ]
then
	echo "打包成功"
fi
