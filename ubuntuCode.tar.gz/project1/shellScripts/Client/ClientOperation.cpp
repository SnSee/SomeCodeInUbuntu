﻿#include "ClientOperation.h"
#include "RequestCodec.h"
#include <string.h>
#include <time.h>
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include "CodecFactory.h"
#include "RequestFactory.h"
#include "RespondFactory.h"
using namespace std;
ClientOperation::ClientOperation(ClientInfo * info)
{
	memcpy(&m_info, info, sizeof(ClientInfo));
	// 创建共享内存对象
	m_shm = new SecKeyShm(info->shmKey, info->maxNode);
}
ClientOperation::~ClientOperation()
{
	m_shm->delShm();
	delete m_shm;
}
int ClientOperation::secKeyAgree()
{
	// 1. 准备好要发送的数据 RequestMsg
	RequestMsg rMsg;
	rMsg.cmdType = 0;
	strcpy(rMsg.clientId, m_info.clinetID);
	strcpy(rMsg.serverId, m_info.serverID);
	getRandString(sizeof(rMsg.r1), rMsg.r1);
	//生成哈希值
	/*unsigned char *HMAC(const EVP_MD *evp_md, const void *key, 
	  int key_len,
      const unsigned char *d, size_t n, unsigned char *md,
      unsigned int *md_len);
	 */
	unsigned char md[SHA256_DIGEST_LENGTH] = "";
	unsigned int md_len;
	const void *hmac_key = "12345";
	int key_len = sizeof(hmac_key);
	HMAC(EVP_sha1(), hmac_key, key_len,
				(const unsigned char *)rMsg.r1, (size_t)sizeof(rMsg.r1),
				md, &md_len);
	//把哈希值用十六进制形式存储到请求结构体中
	int i = 0;
	for(i = 0; i < SHA256_DIGEST_LENGTH; i++){
		sprintf(rMsg.authCode + i * 2, "%02x", md[i]);
	}
	//编码及序列化
	char *outData = NULL;
	int dataLen = 0;
	CodecFactory *factory = new RequestFactory(&rMsg);
	Codec *codec = factory->createCodec();
	codec->msgEncode(&outData, dataLen);

	//发送
	int ret = m_socket.connectToHost(m_info.serverIP, m_info.serverPort);
	if(ret < 0){
		cout << "连接失败" << endl;
		return -1;
	}
	cout << "连接成功" << endl;
	m_socket.sendMsg(outData, dataLen);

	//接收
	char *inData = NULL;
	int indataLen = 0;
	m_socket.recvMsg(&inData, indataLen);

	delete  factory;
	//反序列化及解码
	factory = new RespondFactory();
	codec = factory->createCodec();
	RespondMsg *pMsg = (RespondMsg *)codec->msgDecode(inData, indataLen);
	
	//判断服务器是否成功接收
	if(pMsg->rv == -1){
		cout << "服务器接收失败" << endl;
		return -1;
	}	
/*
unsigned char *SHA1(const unsigned char *d, size_t n, unsigned char *md);
 */
	//生成密钥
	unsigned char md_ulti[SHA_DIGEST_LENGTH] = "";
	char srcData[SHA_DIGEST_LENGTH * 2 + 1] = "";
	char skey[1024] = "";
	sprintf(skey, "%s%s", rMsg.r1, pMsg->r2);
	SHA1((const unsigned char *)skey, strlen(srcData), md_ulti);
	for(i = 0; i < SHA_DIGEST_LENGTH; i++){
		sprintf(srcData + i * 2, "%02x", md_ulti[i]);
	}
	cout << "最终密钥为：" << srcData << endl;

	//将密钥写入共享内存
	NodeSHMInfo shmInfo;
	shmInfo.status = 1;
	shmInfo.seckeyID = pMsg->seckeyid;
	strcpy(shmInfo.clientID, rMsg.clientId);
	strcpy(shmInfo.serverID, rMsg.serverId);
	strcpy(shmInfo.seckey, srcData);
	m_shm->shmWrite(&shmInfo);

	m_socket.freeMemory(&inData);
	m_socket.disConnect();

	return 0;
}
// char randBuf[64]; , 参数 64, randBuf
void ClientOperation::getRandString(int len, char * randBuf)
{
	int flag = -1;
	// 设置随机种子
	srand(time(NULL));
	// 随机字符串: A-Z, a-z, 0-9, 特殊字符(!@#$%^&*()_+=)
	char chars[] = "!@#$%^&*()_+=";
	for (int i = 0; i < len-1; ++i)
	{
		flag = rand() % 4;
		switch (flag)
		{
		case 0:
			randBuf[i] = rand() % 26 + 'A';
			break;
		case 1:
			randBuf[i] = rand() % 26 + 'a';
			break;
		case 2:
			randBuf[i] = rand() % 10 + '0';
			break;
		case 3:
			randBuf[i] = chars[rand() % strlen(chars)];
			break;
		default:
			break;
		}
	}
	randBuf[len - 1] = '\0';
}
