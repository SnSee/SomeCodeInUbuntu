﻿#include <cstdio>
#include "RequestCodec.h"
#include "ClientOperation.h"
#include <iostream>
#include <sys/ipc.h>
#include <sys/types.h>
using namespace std;

int usage();

int main()
{
	ClientInfo info;
	strcpy(info.clinetID, "1111");
	strcpy(info.serverID, "0001");
	strcpy(info.serverIP, "127.0.0.1");
	info.maxNode = 1;
	info.serverPort = 9898;
	info.shmKey = ftok("/", 'm');

	ClientOperation client(&info);
	while (1)
	{
		int ret = -1;
		int nSel = usage();
		switch (nSel)
		{
		case RequestCodec::NewOrUpdate:
			ret = client.secKeyAgree();
			break;
		case RequestCodec::Check:
			ret = client.secKeyCheck();
			break;
		case RequestCodec::Revoke:
			ret = client.secKeyRevoke();
			break;
		case RequestCodec::View:
			ret = client.secKeyView();
			break;
		default:
			return 0;
		}
		if (ret == 0)
		{
			cout << "sucess..." << endl;
		}
		else
		{
			cout << "failed..." << endl;
		}
	}
    return 0;
}

int usage()
{
	int nSel = -1;
	printf("\n  /*************************************************************/");
	printf("\n  /*************************************************************/");
	printf("\n  /*     1.密钥协商                                            */");
	printf("\n  /*     2.密钥校验                                            */");
	printf("\n  /*     3.密钥注销                                            */");
	printf("\n  /*     4.密钥查看                                            */");
	printf("\n  /*     0.退出系统                                            */");
	printf("\n  /*************************************************************/");
	printf("\n  /*************************************************************/");
	printf("\n\n  选择:");

	scanf("%d", &nSel);
	while (getchar() != '\n');

	return nSel;
}