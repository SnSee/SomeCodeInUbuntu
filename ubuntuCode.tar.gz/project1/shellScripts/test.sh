# a test about shell programming
#! /bin/bash
echo "program name: $0"
echo "sec param1: $1"
echo "sec param2: $2"
echo "sec param3: $3"

str="Hello World!"
echo $str

echo "all param: $@"
echo "all param: $*"
echo "param counts: $#"
echo "procid   : $$"
echo "HOME: $HOME"
