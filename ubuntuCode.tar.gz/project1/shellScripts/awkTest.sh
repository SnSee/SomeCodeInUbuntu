#! /bin/bash
ps -ef | grep bash | awk '{print $2}'
