#! /bin/bash

for file in $(ls | grep *.bac)
do
	mv $file $(basename $file .bac)
done
