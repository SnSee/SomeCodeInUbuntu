#!/bin/bash
for fruit in apple pear banana
do
	echo ${fruit}
done

for file in `ls`
do
	echo $file
done

sum=0
for i in {1..100}
do
	sum=$[$sum+$i]	
done
echo "sum==$sum"

for file in `ls *.bak`
do
	mv $file $(basename $file .bak)
done


i=0
sum=0
while [ $i -le 10 ]
do
	sum=$[$sum+$i]
	i=$[$i+1]
done
echo "sum=$sum"
