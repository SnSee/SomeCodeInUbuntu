#include <iostream>
#include <ctime>
#include <string.h>
#include "getRandStr.h"

using namespace std;

int main(int argc, char *argv[]){

	GetRandStr *grs = new GetRandStr();
	while(1){
		char *str = grs->getStr(10);
		printf("str = [%s]\n", str);
		getchar();
		delete []str;
	}

	delete grs;	

	return 0;
}
