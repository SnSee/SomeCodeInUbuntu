#include <iostream>
#include <ctime>
#include <string.h>

using namespace std;
class GetRandStr{
public:
	char *getStr(unsigned int len);
};
