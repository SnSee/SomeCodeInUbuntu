#include "getRandStr.h"

char *GetRandStr::getStr(unsigned int len){
	srand(time(NULL));
	char *p = new char[len];
	int flag = 0;
	int i = 0;
	for(i = 0; i < len; i++){
		flag = rand() % 3;
		switch(flag){
			case 0:
				p[i] = rand() % 10 + '0';	
				break;
			case 1:
				p[i] = rand() % 26 + 'a';
				break;
			case 2:
				p[i] = rand() % 26 + 'A';
				break;
		}
	}
	return p;
}

