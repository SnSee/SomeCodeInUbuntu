#include "dataManager.h"
DataManager::DataManager(){
	buf = new char[BUFSIZ];	
	memset(buf, 0, BUFSIZ);
	sendBuf = new char[BUFSIZ];
	memset(sendBuf, 0, BUFSIZ);
}
DataManager::DataManager(int cfd){
	m_cfd = cfd;
	buf = new char[BUFSIZ];
	memset(buf, 0, BUFSIZ);
}
void DataManager::setConnFd(const int cfd, struct sockaddr_in &cltaddr){
	this->m_cfd = cfd;
	memcpy(&temp_cltaddr, &cltaddr, sizeof(struct sockaddr));
}
int DataManager::recvData(char *data){
	//注意：需要将前四个字节解析为长度
	memset(buf, 0, BUFSIZ);
	int len_r = read(m_cfd, buf, BUFSIZ);
	if(len_r < 0){
		perror("read error");
		return -1;
	}
	else if(0 == len_r){
		printf("客户端关闭了连接\n");
		return ClientStatus::CLOSED;
	}
	data = buf;
	return ClientStatus::CONNECTING;
}

int DataManager::sendData(const char *data, int dataLen){
	//需要将长度信息添加到要发送的字符串中
    //用前四个字节存储长度
    char *dataToSend = (char *)malloc(dataLen + 4);
    memcpy(dataToSend, &dataLen, 4);
    memcpy(dataToSend + 4, buf, dataLen);

	int len_w = write(m_cfd, data, dataLen + 4);
	if(len_w < 0){
		perror("write error");
		return -1;
	}
	else if(0 == len_w){
		printf("客户端已关闭");
		return -1;
	}
	return 0;
}
DataManager::~DataManager(){
	if(NULL != buf){
		delete []buf;
		buf = NULL;
	}
	if(NULL != sendBuf){
		delete []sendBuf;
		sendBuf = NULL;
	}
}
