#include "tcpConnSrv.h"
TcpConnSrv::TcpConnSrv(unsigned int maxevents){
	MAXEVENTS = maxevents;
}
int TcpConnSrv::setListenFd(const short port_num){
	lfd = socket(AF_INET, SOCK_STREAM, 0);
	if(lfd < 0){
		perror("socket error");
		return -1;
	}
	//端口复用
	int opt = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));
	struct sockaddr_in srvaddr;
	srvaddr.sin_family = AF_INET;
	srvaddr.sin_port = htons(port_num);
	srvaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	int ret_bind = bind(lfd, (struct sockaddr*)&srvaddr, sizeof(srvaddr));
	if(ret_bind < 0){
		perror("bind error");
		return -1;
	}
	listen(lfd, 1);
	return 0;
}
int TcpConnSrv::createEpoll(){
	efd = epoll_create(1024);
	if(efd < 0){
		printf("in file:%s line:%d", __FILE__, __LINE__);
		perror("epoll_create error");
		return -1;
	}
	epoll_event ev;
	ev.events = EPOLLIN|EPOLLET;
	ev.data.fd = lfd; 
	//lfd上树
	epoll_ctl(efd, EPOLL_CTL_ADD, lfd, &ev);
	return 0;
}
int TcpConnSrv::startListen(){
	epoll_event ev;
	epoll_event evs[MAXEVENTS];
	int i = 0;
	socklen_t cltlen = 0;
	while(1){
		int nready = epoll_wait(efd, evs, 1024, -1);
		if(nready < 0){
			printf("in file:%s line:%d:\n", __FILE__, __LINE__);
			perror("epoll_wait error");
			return -1;
		}
		for(i = 0; i < nready; i++){
			int sfd = evs[i].data.fd;
			//处理连接请求
			if(sfd == lfd){
				cfd = accept(lfd, (struct sockaddr*)&temp_cltaddr, &cltlen);
				if(cfd < 0){
					perror("accept error");
					continue;
				}
				//TODO:解决第一次连接ip及地址都是0的问题
				char temp_ipClt[32] = "";
				const char *ret = inet_ntop(AF_INET, &temp_cltaddr.sin_addr.s_addr, 
						temp_ipClt, sizeof(temp_ipClt));	
				if(NULL == ret){
					perror("inet_ntop");
				}
				printf("client connected:%s %d\n", temp_ipClt, 
						ntohs(temp_cltaddr.sin_port));
				//通信文件描述符上树
				//设置epoll为ET边缘触发模式
				ev.events = EPOLLIN|EPOLLET;
				ev.data.fd = cfd;
				epoll_ctl(efd, EPOLL_CTL_ADD, cfd, &ev);	
				//客户端ip信息存储到map中
				map_addr.insert(make_pair(cfd, temp_cltaddr));
			}
			//处理通信
			else{
				//多态
				dataManager = new ServerDataManager;
				dataManager->setConnFd(cfd, temp_cltaddr);
				//客户端关闭
				if(dataManager->recvData(data) == ClientStatus::CLOSED){
					struct sockaddr_in temp_clt = map_addr[cfd];
					char cltIp[32] = "";	
					socklen_t ipLen = sizeof(cltIp);
					inet_ntop(AF_INET, &temp_clt.sin_addr.s_addr, 
							cltIp, ipLen);
					printf("client closed:%s:%d\n", cltIp,
							ntohs(temp_clt.sin_port));
					map_addr.erase(cfd);
					continue;
				}	
				//解析请求结构体
				dataManager->parseData();
				//处理请求，包含发送响应消息
				dataManager->disposeData();

				//TODO
			}
		}
	}
	return 0;
}

TcpConnSrv::~TcpConnSrv(){
	if(NULL != dataManager){
		delete dataManager;
		dataManager = NULL;
	}
}
