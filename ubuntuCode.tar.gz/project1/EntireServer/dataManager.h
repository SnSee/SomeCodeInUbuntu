#ifndef __DATAMANAGER_
#define __DATAMANAGER_
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "genRequestMsg.h"
#include "BaseASN1.h"
using namespace std;
enum ClientStatus{
	CONNECTING, CONNECTERROR, CLOSED
};
//用于收发及处理数据
class DataManager{
public:
	DataManager();
	DataManager(int cfd);
	virtual ~DataManager() = 0;
	//设置通信文件描述符及客户端ip信息
	void setConnFd(const int cfd, struct sockaddr_in &cltaddr); 
	//读取数据并返回
	int recvData(char *data);
	//发送数据
	int sendData(const char *data, int dataLen);
private:
protected:
	struct sockaddr_in temp_cltaddr;
	int m_cfd;
	char *buf;			//存储收到的消息
	char *sendBuf;	//存储要发送的消息
};
#endif
