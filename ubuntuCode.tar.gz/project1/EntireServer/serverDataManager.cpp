#include "serverDataManager.h"
ServerDataManager::ServerDataManager(){
	reqMsg = new RequestMsg;
	respondMsg = new RespondMsg;
	genRespondMsg = new GenRespondMsg;
}
RequestMsg *ServerDataManager::parseData(){
	//printf("todelete enter parse\n");
	//getchar();
	//需要将前四个字节解析为长度
	ITCAST_UINT32 itLen;
	memcpy(&itLen, buf, 4);
	//memcpy(&requestLen, buf, 4);
	requestLen = (int)itLen;
	printf("requestLen = %d\n", requestLen);
	GenRequestMsg genReqMsg;
	unsigned char *dataRecvd = (unsigned char *)malloc(requestLen);
	memcpy(dataRecvd, buf + 4, requestLen);
	genReqMsg.getRequestMes(*reqMsg, (char *)dataRecvd, requestLen);
	printf("todelete after getRequestMes\n");
	delete dataRecvd;
	dataRecvd = NULL;
	return reqMsg;
}
RespondMsg *ServerDataManager::getRespondData(){
	return respondMsg;
}
int ServerDataManager::disposeData(){
	//打印请求结构体中的信息验证是否收到正确的消息（Debug）
	displayReqMsg();	
	if(!isOriginalReq()){
		cout << "数据被篡改" << endl;
		return -1;
	}
	else{
		cout << "数据未被篡改" << endl;
	}
	//判断请求类型	
	switch(reqMsg->reqType){
		case REQTYPE::KEY_CONSULT:
			//TODO
			consultSecretKey();
			break;
		case REQTYPE::KEY_CHECK:
			break;
		case REQTYPE::KEY_REVOKE:
			break;
		case REQTYPE::KEY_DISPLAY:
			break;
	}
	return 0;
}
void ServerDataManager::displayReqMsg(){
	printf("\n");
	printf("请求消息如下：\n");
	printf(" reqType:%d\n", reqMsg->reqType);
	printf("clientId:%s\n", reqMsg->clientId);
	printf("serverId:%s\n", reqMsg->serverId);
	printf(" randStr:%s\n", reqMsg->rstr);
	printf("authcode:%s\n", reqMsg->authCode);
	printf("\n");
}
bool ServerDataManager::isOriginalReq(){
	//计算字符串rstr的哈希值并与传进来的哈希值比较
	char dest[SHA256_DIGEST_LENGTH * 2 + 1] = "";
	HashStr hashStr;
	hashStr.hashlizeStr(dest, reqMsg->rstr, 64);	
	if(strcmp(dest, reqMsg->authCode) != 0){
		return false;
	}
	return true;
}
//进行密钥协商
int ServerDataManager::consultSecretKey(){
	respondMsg->respondType = RESPONDTYPE::RECV_SUCCEED;
	strcpy(respondMsg->clientId, reqMsg->clientId);
	//TODO:serverId应该是固有属性，以后再添加
	strcpy(respondMsg->serverId, reqMsg->serverId);
	//TODO:密钥id以后根据生成的密钥来设置
	respondMsg->secretKeyId = 10;
	char *inData = genRespondMsg->setRespondMes(*respondMsg, &respondLen);

	//TODO:检测是否生成及发送了正确数据
	char tempinData[12] = "";
	for(int i = 0; i < 5; i++){
		sprintf(tempinData + i*2, "%02x", inData[i]);
	}
	sendData(inData, respondLen);
	printf("respondLen = %d\n", respondLen);
	printf("密钥协商响应已发送\n");
	free(inData);
	inData = NULL;
	return 0;
}
ServerDataManager::~ServerDataManager(){
	if(NULL != reqMsg){
		delete reqMsg;
		reqMsg = NULL;
	}
	if(NULL != respondMsg){
		delete respondMsg;
		respondMsg = NULL;
	}
	if(NULL != genRespondMsg){
		delete genRespondMsg;
		genRespondMsg = NULL;
	}
}
