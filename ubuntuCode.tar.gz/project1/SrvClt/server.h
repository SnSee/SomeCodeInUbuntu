#ifndef __SERVER__
#define __SERVER__
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
using namespace std;

class Server{
public:
	//设置监听文件描述符并创建epoll监听树
	Server();
	~Server();
	//开启监听并创建通信文件描述符或者进行通信
	int startWait();
	//发送相应消息, i 是evs的下标，表明是哪个文件描述符
	int sendMes(int i);
	//收取信息
	int recvMes(int i);
	//处理数据
	int disposeMes(int i);
	//准备响应数据
	int prepareMes();
private:
	struct epoll_event *ev, *evs;
	struct sockaddr_in *srvaddr, *cltaddr;
	char *buf;
	int lfd, cfd, efd;	
	socklen_t len_cltaddr;
	const unsigned int MAXNUM = 1024;
};

#endif
