#include <iostream>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <ctype.h>
#include <sys/epoll.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

//the server class
class Server{
public:
	Server(){
		srvaddr = new struct sockaddr_in;
		cltaddr = new struct sockaddr_in;
		evs = new struct epoll_event[1024];
		buf = new char[BUFSIZ];
		lfd = socket(AF_INET, SOCK_STREAM, 0);
		opt = 1;
		setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));
		srvaddr->sin_family = AF_INET;
		srvaddr->sin_port = htons(SRV_PORT);
		srvaddr->sin_addr.s_addr = htonl(INADDR_ANY);
		bind(lfd, (struct sockaddr *)srvaddr, sizeof(struct sockaddr));
		listen(lfd, 256);

		efd = epoll_create(256);
		ev.events = EPOLLIN;
		ev.data.fd = lfd;
		epoll_ctl(efd, EPOLL_CTL_ADD, lfd, &ev);
	}
	int startWait(){
		int nready = 0;	
		int i = 0;
		int len_r = 0, len_w = 0;
		while(1){
			nready = epoll_wait(efd, evs, maxEvents, -1);	
			if(nready < 0){
				perror("epoll_wait");
				continue;
			}
			for(i = 0; i < nready; i++){
				socklen_t len_clt;
				if(lfd == evs[i].data.fd){
					cfd = accept(lfd, (struct sockaddr *)cltaddr, &len_clt);
					ev.events = EPOLLIN;
					ev.data.fd = cfd;
					epoll_ctl(efd, EPOLL_CTL_ADD, cfd, &ev);
				}
				else{
					len_r = read(evs[i].data.fd, buf, BUFSIZ);
					if(len_r < 0){
						perror("read");
						exit(-1);
					}
					else if(len_r == 0){
						printf("client closed\n");
						close(evs[i].data.fd);
						epoll_ctl(efd, EPOLL_CTL_DEL, evs[i].data.fd, NULL);
						continue;
					}
					else{
						buf[0] = toupper(buf[0]);	
						len_w = write(evs[i].data.fd, buf, strlen(buf) + 1);
					}
				}
			}
		}
	}
	~Server(){
		delete []evs;
		delete srvaddr;
		delete cltaddr;
		delete []buf;
	}
private:
	struct epoll_event ev;
	struct sockaddr_in *srvaddr;
	struct sockaddr_in *cltaddr;
	struct epoll_event *evs;
	char *buf;
	int lfd;
	int efd;
	int opt;
	int cfd;
	const short SRV_PORT = 8000;
	const unsigned short maxEvents = 1024;
};

int main(int argc, char *argv[]){

	Server srv;
	srv.startWait();

	return 0;
}
