#include <iostream>
#include "server.h"
using namespace std;

void func1(){
	Server s;
	s.startWait();
}
int main(int argc, char *argv[]){

	func1();
	return 0;
}
