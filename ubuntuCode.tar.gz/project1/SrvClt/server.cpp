#include "server.h"

Server::Server(){
	//初始化
	srvaddr = new struct sockaddr_in;
	cltaddr = new struct sockaddr_in;
	ev = new struct epoll_event;
	evs = new struct epoll_event[MAXNUM];
	buf = new char[BUFSIZ];
//在构造方法中创建监听文件描述符
	if((lfd = socket(AF_INET, SOCK_STREAM, 0)) < 0){
		perror("socket");
		exit(-1);
	};
	//设置端口复用
	int opt = 1;
	setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, (void *)&opt, sizeof(opt));
	srvaddr->sin_family = AF_INET;
	srvaddr->sin_port = htons(8000);
	srvaddr->sin_addr.s_addr = htonl(INADDR_ANY);
	if(0 > (bind(lfd, (struct sockaddr *)srvaddr, sizeof(struct sockaddr)))){
		perror("bind");
		exit(-1);
	}
	listen(lfd, 256);
	//printf("lfd = %d\n", lfd);

	//创建监听树并将lfd添加到树上
	efd = epoll_create(MAXNUM);
	if(efd < 0){
		perror("epoll_create");
		exit(-1);
	}
	ev->events = EPOLLIN;
	ev->data.fd = lfd;
	if(0 > epoll_ctl(efd, EPOLL_CTL_ADD, lfd, ev)){
		perror("epoll_ctl");
		exit(-1);
	}	
}
int Server::startWait(){
	int nready = 0;
	int i = 0;
	while(1){
		nready = epoll_wait(efd, evs, MAXNUM, -1);
		if(nready < 0){
			perror("epoll_wait");
			exit(-1);
		}
		for(i = 0; i < nready; i++){
			//有新的连接请求
			if(lfd == evs[i].data.fd){
				printf("lfd = %d\n", lfd);
				cfd = accept(lfd, (struct sockaddr*)cltaddr, &len_cltaddr);
				printf("cfd = %d\n", cfd);
				if(cfd < 0){
					perror("accept");
					continue;
				}
				//通信文件描述符上树
				ev->events = EPOLLIN;
				ev->data.fd = cfd;
				if(0 > epoll_ctl(efd, EPOLL_CTL_ADD, cfd, ev)){
					perror("cfd epoll_wait");
					continue;
				}
			}
			else{
				//处理数据(收取，处理，发送)
				disposeMes(i);
			}
		}
	}
}
//处理数据
int Server::disposeMes(int i){
	int ret = recvMes(i);
	if(ret < 0){
		return -1;
	}
	else if(ret == 1){
		return 1;
	}
	prepareMes();
	ret = sendMes(i);
	if(ret < 0){
		return -1;
	}
	return 0;
}
//收取数据
int Server::recvMes(int i){
	int len_r = read(evs[i].data.fd, buf, BUFSIZ);
	if(0 > len_r){
		perror("read");
		return -1;
	}
	else if(len_r == 0){
		printf("client closed\n");
		close(evs[i].data.fd);
		return 1;
	}
	return 0;
}
//准备响应数据
int Server::prepareMes(){
	buf[0] = toupper(buf[0]);
	return 0;
}
//发送响应数据
int Server::sendMes(int i){
	int len_w = write(evs[i].data.fd, buf, strlen(buf) + 1);
	if(len_w < 0){
		perror("response write");
		return -1;
	}
	return 0;
}
Server::~Server(){
	//释放内存
	if(srvaddr){
		delete srvaddr;
		srvaddr = NULL;
	}
	if(cltaddr){
		delete cltaddr;
		cltaddr = NULL;
	}
	if(ev){
		delete ev;
		ev = NULL;
	}
	if(evs){
		delete []evs;
		evs = NULL;
	}
	if(buf){
		delete []buf;
		buf = NULL;
	}
}
