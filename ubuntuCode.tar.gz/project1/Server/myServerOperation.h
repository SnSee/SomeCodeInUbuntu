#ifndef __MY_SERVER_OPERATION__
#define __MY_SERVER_OPERATION__
#include <iostream>
#include <map>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include "TcpSocket.h"
#include "SecKeyShm.h"
#include "TcpServer.h"
#include "RequestCodec.h"
#include "RespondCodec.h"
#include "ServerOperation.h"
#include <iostream>
#include <pthread.h>
#include <string.h>
#include "RequestFactory.h"
#include "RespondFactory.h"
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include <signal.h>

using namespace std;
//class ServerInfo
//{
//public:
//    char            serverID[12];   // 服务器端编号
//    char            dbUse[24];      // 数据库用户名
//    char            dbPasswd[24];   // 数据库密码
//    char            dbSID[24];      // 数据库sid
//
//    unsigned short  sPort;          // 服务器绑定的端口
//    int             maxnode;        // 共享内存最大网点树 客户端默认1个
//    int             shmkey;         // 共享内存keyid 创建共享内存时使用  
//};
class MyServerOperation{
public:
	friend void *workThread(void *arg);
	MyServerOperation(ServerInfo *info);
	~MyServerOperation();

	void startServer();
int consultKey(RequestMsg *reqMsg, char **outData, int *outDataLen);
private:
	void sig_handler(int arg);
	void getRandString(int len, char * randBuf);

	map<pthread_t, TcpServer*> m_socketMap;
	ServerInfo m_info;
	SecKeyShm *m_shmKey;
	TcpServer m_server;
	TcpSocket *m_client;
	static bool isWorking;
};
	void *workThread(void *arg);
#endif
