﻿#include "ServerOperation.h"
#include <iostream>
#include <pthread.h>
#include <string.h>
#include "RequestFactory.h"
#include "RespondFactory.h"
#include <openssl/hmac.h>
#include <openssl/sha.h>
#include <signal.h>
//#include "OCCIOP.h"
using namespace std;

bool ServerOperation::m_stop = false;	// 静态变量初始化

void ServerOperation::catchSignal(int signo)
{
	m_stop = true;
}

ServerOperation::ServerOperation(ServerInfo * info)
{
	memcpy(&m_info, info, sizeof(ServerInfo));
	//创建共享内存
	m_shm = new SecKeyShm(m_info.shmkey, m_info.maxnode);

	//连接数据库
	string connstr = "192.169.10.145:1521/orcl";
	//bool bl = m_occi.connectDB(m_info.dbUse, m_info.dbPasswd, connstr);
//	bool bl = m_occi.connectDB("SECMNG", "SECMNG", "192.168.10.145/orcl");
//	if(!bl)
//	{
//		cout << "connect database error" << endl;
//	}
}

ServerOperation::~ServerOperation()
{
	//关闭数据库
	//m_occi.closeDB();

}

void ServerOperation::startWork()
{
	//socket--setsockopt---bind---listen
	m_server.setListen(m_info.sPort);

	while (1)
	{
		//接受客户端连接请求
		m_client = m_server.acceptConn();
		if (m_client == NULL)
		{
			continue;
		}

		//创建子线程
		pthread_t tid;
		pthread_create(&tid, NULL, working, this);

		m_listSocket.insert(make_pair(tid, m_client));
		//将子线程设置为分离属性
		pthread_detach(tid);
	}
}

int ServerOperation::secKeyAgree(RequestMsg * reqMsg, char ** outData, int & outLen)
{
	//检查clientID是否合法

	//检查r1是否被篡改过
	unsigned int len;
	char key[32] = {0};
	char mdBuf[SHA256_DIGEST_LENGTH*2+1];
	unsigned char md[SHA256_DIGEST_LENGTH] = { 0 };
	sprintf(key, "@%s+%s@", reqMsg->serverId, reqMsg->clientId);
	HMAC(EVP_sha256(), key, strlen(key), (unsigned char *)reqMsg->r1, strlen(reqMsg->r1), md, &len);
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
	{
		sprintf(&mdBuf[i*2], "%02x", md[i]);
	}
	cout << "消息认证码: " << mdBuf << endl;

	//判断消息认证码是否相同
	if (strcmp(mdBuf, reqMsg->authCode) != 0)
	{
		cout << "消息认证码不一致" << endl;
		return -1;
	}

	//生成随机字符串
	RespondMsg rspMsg;
	memset(&rspMsg, 0x00, sizeof(rspMsg));
	getRandString(sizeof(rspMsg.r2), rspMsg.r2);
	cout << "服务端生成的随机字符串: " << rspMsg.r2;

	//生成秘钥
	char buf[128] = { 0 };
	unsigned char md1[SHA_DIGEST_LENGTH] = { 0 };
	char mdBuf1[SHA_DIGEST_LENGTH * 2 + 1] = { 0 };
	sprintf(buf, "%s%s", reqMsg->r1, rspMsg.r2);
	SHA1((unsigned char *)buf, strlen((char *)buf), md1);
	for (int i = 0; i < SHA_DIGEST_LENGTH; i++)
	{
		sprintf(&mdBuf1[i * 2], "%02x", md1[i]);
	}
	cout << "客户端生成的秘钥: " << mdBuf1 << endl;

	//将秘钥信息写入数据库

	//将秘钥信息写入共享内存
	NodeSHMInfo shmInfo;
	shmInfo.status = 0;
	shmInfo.seckeyID = 9999;
	strcpy(shmInfo.clientID, reqMsg->clientId);
	strcpy(shmInfo.serverID, m_info.serverID);
	strcpy(shmInfo.seckey, mdBuf1);

	//将秘钥信息写入共享内存
	m_shm->shmWrite(&shmInfo);

	//给应答结构体赋值
	strcpy(rspMsg.clientId, reqMsg->clientId);
	strcpy(rspMsg.serverId, m_info.serverID);
	rspMsg.seckeyid = 9999;
	rspMsg.rv = 0;

	//编码和序列化rspMsg结构体变量
	CodecFactory *factory = new RespondFactory(&rspMsg);
	Codec *pCodec = factory->createCodec();
	pCodec->msgEncode(outData, outLen);

	delete factory;
	delete pCodec;

	return 0;
}



void ServerOperation::getRandString(int len, char * randBuf)
{
	int flag = -1;
	// 设置随机种子
	srand(time(NULL));
	// 随机字符串: A-Z, a-z, 0-9, 特殊字符(!@#$%^&*()_+=)
	char chars[] = "!@#$%^&*()_+=";
	for (int i = 0; i < len - 1; ++i)
	{
		flag = rand() % 4;
		switch (flag)
		{
		case 0:
			randBuf[i] = 'Z' - rand() % 26;
			break;
		case 1:
			randBuf[i] = 'z' - rand() % 26;
			break;
		case 3:
			randBuf[i] = rand() % 10 + '0';
			break;
		case 2:
			randBuf[i] = chars[rand() % strlen(chars)];
			break;
		default:
			break;
		}
	}
	randBuf[len - 1] = '\0';
}

// 友元函数, 可以在该友元函数中通过对应的类对象调用期私有成员函数或者私有变量
// 子线程 - 进行业务流程处理
void * working(void * arg)
{
	ServerOperation *sop = (ServerOperation *)arg;
	pthread_t tid = pthread_self();
	TcpSocket* tcpSock = sop->m_listSocket[tid];

	//接收客户端发送的数据
	char *inData = NULL;
	int dataLen;
	tcpSock->recvMsg(&inData, dataLen);

	//解码
	CodecFactory *factory = new RequestFactory();
	Codec *pCodec = factory->createCodec();
	RequestMsg *pReqMsg = (RequestMsg *)pCodec->msgDecode(inData, dataLen);

	//判断cmdType的值
	char *outData;
	switch (pReqMsg->cmdType)
	{
	case RequestCodec::NewOrUpdate:
		// 秘钥协商函数
		sop->secKeyAgree(pReqMsg, &outData, dataLen);
		break;
	case RequestCodec::Check:
		break;
	case RequestCodec::Revoke:
		break;
	default:
		break;
	}

	//发送数据给客户端
	tcpSock->sendMsg(outData, dataLen);

	//关闭网络连接
	tcpSock->disConnect();

	return 0;
}
