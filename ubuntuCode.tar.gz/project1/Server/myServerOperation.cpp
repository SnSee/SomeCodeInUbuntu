#include "myServerOperation.h"
bool MyServerOperation::isWorking = true;
MyServerOperation::MyServerOperation(ServerInfo *info){
	memcpy(&m_info, info, sizeof(ServerInfo));
	m_shmKey = new SecKeyShm(m_info.shmkey, m_info.maxnode);	
}
MyServerOperation::~MyServerOperation(){

}
void MyServerOperation::startServer(){
	m_server.setListen(m_info.sPort);
	while(1){
		m_client = m_server.acceptConn();
		if(NULL == m_client){
			cout << "connect error" << endl;
			continue;
		}
		pthread_t tid;
        pthread_create(&tid, NULL, workThread, this);
        pthread_detach(tid);
        
		m_socketMap.insert(make_pair(tid, m_client));
	}
}
void *workThread(void *arg){
	MyServerOperation *sop = (MyServerOperation *)arg;
	pthread_t tid = pthread_self();
	TcpSocket *tcpSock = sop->m_socketMap[tid];
	
	char *inData = NULL;
	int dataLen;
	tcpSock->recvMsg(&inData, dataLen);

	CodecFactory *factory = new RespondFactory();
	Codec *pCodec = factory->createCodec();
	RequestMsg *pReqMsg = (RequestMsg *)pCodec->msgDecode(inData, dataLen);

	char *outData;
	switch(pReqMsg->cmdType){
		case RequestCodec::NewOrUpdate:
			sop->consultKey(pReqMsg, &outData, &dataLen);
			break;
		case RequestCodec::Check:
			break;
		case RequestCodec::Revoke:
			break;
	}
	tcpSock->sendMsg(outData, dataLen);
	tcpSock->disConnect();
	return 0;
}
int MyServerOperation::consultKey(RequestMsg *reqMsg, char **outData, int *outDataLen){
	unsigned int len;
	char key[32] = "";
	char buf[SHA256_DIGEST_LENGTH * 2 + 1] = "";
	unsigned char md[SHA256_DIGEST_LENGTH] = "";
	sprintf(key, "%s%s", reqMsg->serverId, reqMsg->clientId);
	HMAC(EVP_sha256(), key, strlen(key), (unsigned char *)reqMsg->r1, strlen(reqMsg->r1), md, &len);
	int i = 0;
	for(i = 0; i < SHA256_DIGEST_LENGTH; i++){
		sprintf(buf + i*2, "%02x", md[i]);
	}

	if(strcmp(buf, reqMsg->authCode) != 0){
		cout << "messege received unsafe" << endl;
		return -1;
	}

	RespondMsg resMsg;
	memset(&resMsg, 0, sizeof(resMsg));
	getRandString(sizeof(resMsg.r2), resMsg.r2);
	
	char buf2[128] = "";
	unsigned char md1[SHA256_DIGEST_LENGTH] = "";
	char mdBuf1[SHA256_DIGEST_LENGTH * 2 + 1] = "";
	sprintf(buf2, "%s%s", reqMsg->r1, resMsg.r2);
	SHA1((unsigned char *)buf2, strlen((char *)buf2), md1);
	for(int i = 0; i < SHA256_DIGEST_LENGTH; i++){
		sprintf(&mdBuf1[i*2], "%02x", md1[i]);
	}

	NodeSHMInfo shmInfo;
	shmInfo.status = 0;
	shmInfo.seckeyID = 8000;
	strcpy(shmInfo.clientID, reqMsg->clientId);
	strcpy(shmInfo.serverID, m_info.serverID);
	strcpy(shmInfo.seckey, mdBuf1);

	m_shmKey->shmWrite(&shmInfo);

	strcpy(resMsg.clientId, reqMsg->clientId);
	strcpy(resMsg.serverId, m_info.serverID);
	resMsg.seckeyid = 8000;
	resMsg.rv = 0;

	CodecFactory *factory = new RespondFactory(&resMsg);
	Codec *pCodec = factory->createCodec();
	pCodec->msgEncode(outData, *outDataLen);

	delete factory;
	delete pCodec;

	return 0;
}

void MyServerOperation::sig_handler(int arg){
	isWorking = false;
}
void ServerOperation::getRandString(int len, char * randBuf)
{
    int flag = -1;
    // 设置随机种子
    srand(time(NULL));
    // 随机字符串: A-Z, a-z, 0-9, 特殊字符(!@#$%^&*()_+=)
    char chars[] = "!@#$%^&*()_+=";
    for (int i = 0; i < len - 1; ++i)
    {
        flag = rand() % 4;
        switch (flag)
        {
        case 0:
            randBuf[i] = 'Z' - rand() % 26;
            break;
        case 1:
            randBuf[i] = 'z' - rand() % 26;
            break;
        case 3:
            randBuf[i] = rand() % 10 + '0';
            break;
        case 2:
            randBuf[i] = chars[rand() % strlen(chars)];
            break;
        default:
            break;
        }
    }
    randBuf[len - 1] = '\0';
}

