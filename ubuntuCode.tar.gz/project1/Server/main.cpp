﻿#include <cstdio>
#include "ServerOperation.h"
#include <sys/ipc.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <iostream>
using namespace std;

void createDaemon()
{
	//父进程fork子进程,然后exit
	pid_t pid = fork();
	if(pid<0 || pid>0)
	{
		exit(0);
	}

	//子进程调用setsid函数创建会话
	setsid();

	//修改当前的工作目录
	chdir("/home/itcast/projects/SecKeyServer");

	//修改当前进程的文件掩码
	umask(0000);

	//关闭或者重定向STDIN_FILENO, STDOUT_FILENO, STDERR_FILENO
	int fd = open("/dev/null", O_RDWR);
	dup2(fd, STDIN_FILENO);
	dup2(fd, STDOUT_FILENO);
	dup2(fd, STDERR_FILENO);
}
void createDaemon2(){
	int fid = fork();
	if(fid != 0){
		exit(0);
	}
	pid_t pid = setsid();
	if(pid < 0){
		perror("setid failed");
		return;
	}

	chdir("/home/snsee/project1/Server");
	umask(0000);

	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);
}
int main()
{
	//设置为守护进程
	//createDaemon();
	createDaemon2();
	
	//注册SIGUSR1信号处理函数
	struct sigaction act;
	act.sa_flags = 0;
	act.sa_handler = ServerOperation::catchSignal;
	sigemptyset(&act.sa_mask);
	sigaction(SIGUSR1, &act, NULL);
	
	ServerInfo info;
	strcpy(info.serverID, "0001");
	info.maxnode = 10;
	info.shmkey = 0x12340000;
	strcpy(info.dbUse, "SECMNG");
	strcpy(info.dbPasswd, "SECMNG");
	strcpy(info.dbSID, "orcl");
	info.sPort = 9898;

	ServerOperation server(&info);
	server.startWork();

    return 0;
}
