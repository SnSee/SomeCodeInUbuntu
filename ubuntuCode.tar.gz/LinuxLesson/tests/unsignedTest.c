#include <stdio.h>

int main(int argc, char *argv[]){
	unsigned int a = -1;
	printf("unsigned a = %u\n", a);
	printf("signed a = %d\n", a);
}
