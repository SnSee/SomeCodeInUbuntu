#include <stdio.h>
int main(int argc, char *argv[]){
	printf("hello world\n");
	printf("this is my first programming in Linux\n");
	return 0;
}
