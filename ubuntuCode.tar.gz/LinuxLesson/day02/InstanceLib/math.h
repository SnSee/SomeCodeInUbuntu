#ifndef __MATH_H_
#define __MATH_H_

extern int add(int a, int b);
extern int sub(int a, int b);

#endif
