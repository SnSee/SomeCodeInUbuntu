#include <stdio.h>

int main(int argc, char *argv[]){
	int a;
	scanf("%d", &a);
	printf("a = %d", a);
	return 0;
}
