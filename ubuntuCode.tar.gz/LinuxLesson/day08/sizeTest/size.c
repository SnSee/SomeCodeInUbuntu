#include <stdio.h>

int main(int argc, char *argv[]){
	printf("sizeof(int) = %ld\n", sizeof(int));
	printf("sizeof(void *) = %ld\n", sizeof(void *));
	return 0;
}
